# Task 1 - Personal Portfolio Website

Responsive personal portfolio built with **HTML5, CSS3 and Bootstrap 5**.

## Sections
- Navbar (sticky, collapses into a hamburger menu on mobile, scroll-spy highlighting)
- Hero / Header
- About Me
- Skills (progress bars + badges)
- Featured Projects (Bootstrap cards)
- Contact Form (Bootstrap validation + success message)

## How to run
Open `index.html` in any browser (Bootstrap is loaded from the jsDelivr CDN).

## Files
| File | Purpose |
|------|---------|
| `index.html` | Page structure and Bootstrap components |
| `style.css`  | Custom theme, animations and media queries |
| `script.js`  | Contact form validation |

## Responsiveness
Tested on mobile (390px), tablet (768px) and desktop (1366px) using the Bootstrap grid (`col-*`, `col-md-*`, `col-lg-*`) and custom media queries.
