import { useState } from 'react';
import { getBill } from '../reducers/cartReducer.js';

// Props: cart, dispatch, onNavigate()
export default function CartPage({ cart, dispatch, onNavigate }) {
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState('');
  const bill = getBill(cart);

  const applyCoupon = () => {
    if (code.trim().toUpperCase() === 'FOOD10') {
      dispatch({ type: 'APPLY_COUPON', code: 'FOOD10' });
      setMsg('Coupon applied: 10% off!');
    } else {
      setMsg('Invalid coupon code.');
    }
  };

  if (cart.items.length === 0) {
    return (
      <div className="container center-box">
        <h2>Your cart is empty</h2>
        <p>Add some delicious dishes from the menu.</p>
        <button className="btn btn-primary" onClick={() => onNavigate('menu')}>Browse Menu</button>
      </div>
    );
  }

  return (
    <div className="container page">
      <h2>Your Cart</h2>
      <div className="cart-layout">
        <div className="cart-list">
          {cart.items.map((i) => (
            <div className="cart-row" key={i.id}>
              <div>
                <h4>{i.name}</h4>
                <span className="muted">&#8377;{i.price} each</span>
              </div>
              <div className="qty">
                <button onClick={() => dispatch({ type: 'DECREASE', id: i.id })}>-</button>
                <span>{i.qty}</span>
                <button onClick={() => dispatch({ type: 'INCREASE', id: i.id })}>+</button>
              </div>
              <strong>&#8377;{i.price * i.qty}</strong>
              <button className="remove" onClick={() => dispatch({ type: 'REMOVE', id: i.id })}>Remove</button>
            </div>
          ))}
        </div>

        <aside className="summary">
          <h3>Bill Summary</h3>
          <div className="coupon">
            <input placeholder="Coupon (try FOOD10)" value={code} onChange={(e) => setCode(e.target.value)} />
            <button className="btn btn-dark" onClick={applyCoupon}>Apply</button>
          </div>
          {msg && <small className={cart.coupon ? 'ok' : 'err'}>{msg}</small>}
          <div className="line"><span>Subtotal</span><span>&#8377;{bill.subtotal}</span></div>
          {bill.discount > 0 && <div className="line ok"><span>Discount</span><span>- &#8377;{bill.discount}</span></div>}
          <div className="line"><span>GST (5%)</span><span>&#8377;{bill.gst}</span></div>
          <div className="line"><span>Delivery</span><span>{bill.delivery === 0 ? 'FREE' : `₹${bill.delivery}`}</span></div>
          <div className="line total"><span>Total</span><span>&#8377;{bill.total}</span></div>
          <button className="btn btn-primary full" onClick={() => onNavigate('checkout')}>Proceed to Checkout</button>
          <button className="btn-link" onClick={() => dispatch({ type: 'CLEAR' })}>Clear cart</button>
        </aside>
      </div>
    </div>
  );
}
