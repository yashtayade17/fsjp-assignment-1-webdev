// Small SVG illustrations (one per category) used instead of photos
export default function DishIcon({ category }) {
  const common = { width: 72, height: 72, viewBox: '0 0 64 64', fill: 'none' };
  switch (category) {
    case 'Pizza':
      return (
        <svg {...common}><path d="M32 58 6 14a44 44 0 0 1 52 0L32 58Z" fill="#fde68a" stroke="#fff" strokeWidth="3"/>
          <circle cx="24" cy="24" r="4" fill="#dc2626"/><circle cx="40" cy="24" r="4" fill="#dc2626"/><circle cx="32" cy="38" r="4" fill="#dc2626"/></svg>
      );
    case 'Burgers':
      return (
        <svg {...common}><path d="M8 28a24 18 0 0 1 48 0Z" fill="#fbbf24"/><rect x="8" y="30" width="48" height="6" rx="3" fill="#16a34a"/>
          <rect x="8" y="37" width="48" height="8" rx="4" fill="#7c2d12"/><path d="M8 47h48a10 8 0 0 1-48 0Z" fill="#fbbf24"/></svg>
      );
    case 'Indian':
      return (
        <svg {...common}><path d="M6 30h52a26 24 0 0 1-52 0Z" fill="#fff"/><path d="M14 30c2-10 34-10 36 0Z" fill="#fcd34d"/>
          <path d="M20 14c-3 4 3 6 0 10M32 12c-3 4 3 6 0 10M44 14c-3 4 3 6 0 10" stroke="#fff" strokeWidth="3" strokeLinecap="round"/></svg>
      );
    case 'Desserts':
      return (
        <svg {...common}><path d="M14 34h36l-5 20H19Z" fill="#fff"/><path d="M12 34a20 18 0 0 1 40 0Z" fill="#fbcfe8"/>
          <circle cx="32" cy="12" r="5" fill="#dc2626"/></svg>
      );
    default:
      return (
        <svg {...common}><path d="M16 12h32l-4 44H20Z" fill="#fff" fillOpacity=".9"/><path d="M18 26h28l-2 30H20Z" fill="#fde68a"/>
          <path d="M36 4 32 24" stroke="#fff" strokeWidth="4" strokeLinecap="round"/></svg>
      );
  }
}
