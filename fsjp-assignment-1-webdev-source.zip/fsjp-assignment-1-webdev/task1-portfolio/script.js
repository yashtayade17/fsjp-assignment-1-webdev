// Contact form validation + success message (Bootstrap validation classes)
(function () {
  'use strict';
  const form = document.getElementById('contactForm');
  const alertBox = document.getElementById('formAlert');

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    event.stopPropagation();

    if (form.checkValidity()) {
      const name = document.getElementById('name').value.trim();
      alertBox.textContent = 'Thank you, ' + name + '! Your message has been sent successfully.';
      alertBox.classList.remove('d-none');
      form.reset();
      form.classList.remove('was-validated');
    } else {
      alertBox.classList.add('d-none');
      form.classList.add('was-validated');
    }
  });
})();
