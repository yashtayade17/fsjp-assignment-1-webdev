import { useReducer, useState, useEffect } from 'react';
import { cartReducer, initialCart, getBill } from './reducers/cartReducer.js';
import Navbar from './components/Navbar.jsx';
import MenuPage from './components/MenuPage.jsx';
import CartPage from './components/CartPage.jsx';
import CheckoutPage from './components/CheckoutPage.jsx';
import OrderSuccess from './components/OrderSuccess.jsx';

export default function App() {
  const [cart, dispatch] = useReducer(cartReducer, initialCart);   // global cart state
  const [view, setView] = useState('menu');                         // view toggling (SPA routing)
  const [order, setOrder] = useState(null);
  const [toast, setToast] = useState('');

  const cartCount = cart.items.reduce((n, i) => n + i.qty, 0);

  // Navigate to a view and scroll to top
  const navigate = (next) => {
    setView(next);
    window.scrollTo(0, 0);
  };

  const handleAdd = (item) => {
    dispatch({ type: 'ADD', item });
    setToast(`${item.name} added to cart`);
  };

  // Hide the toast after 1.8 seconds
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 1800);
    return () => clearTimeout(t);
  }, [toast]);

  const placeOrder = (details) => {
    setOrder({ ...details, id: 'FH' + Math.floor(100000 + Math.random() * 900000), total: getBill(cart).total });
    dispatch({ type: 'CLEAR' });
    navigate('success');
  };

  return (
    <>
      <Navbar view={view} cartCount={cartCount} onNavigate={navigate} />
      {view === 'menu' && <MenuPage cartItems={cart.items} onAdd={handleAdd} />}
      {view === 'cart' && <CartPage cart={cart} dispatch={dispatch} onNavigate={navigate} />}
      {view === 'checkout' && <CheckoutPage cart={cart} onPlaceOrder={placeOrder} onNavigate={navigate} />}
      {view === 'success' && order && <OrderSuccess order={order} onNavigate={navigate} />}
      {toast && <div className="toast">{toast}</div>}
      <footer className="footer">&copy; 2026 FoodieHub - React SPA Project</footer>
    </>
  );
}
