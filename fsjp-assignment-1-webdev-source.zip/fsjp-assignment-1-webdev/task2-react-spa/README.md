# Task 2 - FoodieHub (Online Food Ordering SPA)

A single-page application built with **React.js** (Vite).

## Features
- Menu with category filter, live search, veg-only toggle and sorting
- Cart with add / increase / decrease / remove (managed with `useReducer`)
- Coupon code (`FOOD10` = 10% off), GST and delivery-fee calculation
- Checkout form with validation, and an order confirmation page
- View toggling (Menu -> Cart -> Checkout -> Success) without page reload
- Fully responsive layout (mobile, tablet, desktop)

## React concepts used
| Concept | Where |
|---------|-------|
| Functional components | every file in `src/components` |
| `useState` | filters, form fields, current view (`App.jsx`) |
| `useReducer` | cart state (`reducers/cartReducer.js`) |
| `useEffect` | toast auto-hide (`App.jsx`) |
| Props | `MenuCard`, `Navbar`, `CartPage`, `CheckoutPage`, ... |
| View toggling / routing | `view` state in `App.jsx` |

## Run locally
```bash
npm install
npm run dev
```

## Project structure
```
src/
  App.jsx            # root component, view toggling, cart state
  main.jsx           # entry point
  index.css          # styles
  data/menu.js       # menu items
  reducers/cartReducer.js
  components/        # Navbar, MenuPage, MenuCard, CartPage, CheckoutPage, OrderSuccess, DishIcon
```
