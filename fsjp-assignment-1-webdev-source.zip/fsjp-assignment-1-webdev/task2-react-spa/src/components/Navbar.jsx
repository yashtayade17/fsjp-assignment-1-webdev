// Props: view (current page), cartCount, onNavigate()
export default function Navbar({ view, cartCount, onNavigate }) {
  return (
    <nav className="navbar">
      <button className="brand" onClick={() => onNavigate('menu')}>
        Foodie<span>Hub</span>
      </button>
      <div className="nav-links">
        <button className={view === 'menu' ? 'active' : ''} onClick={() => onNavigate('menu')}>Menu</button>
        <button className={view === 'cart' || view === 'checkout' ? 'active' : ''} onClick={() => onNavigate('cart')}>
          Cart <span className="cart-badge">{cartCount}</span>
        </button>
      </div>
    </nav>
  );
}
