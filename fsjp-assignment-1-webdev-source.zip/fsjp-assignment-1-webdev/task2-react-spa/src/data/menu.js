// Static menu data (acts as our "database")
export const CATEGORIES = ['All', 'Pizza', 'Burgers', 'Indian', 'Desserts', 'Drinks'];

export const MENU = [
  { id: 1,  name: 'Margherita Pizza',    category: 'Pizza',    price: 249, rating: 4.5, veg: true,  desc: 'Classic tomato, basil and mozzarella.',  color: '#f97316' },
  { id: 2,  name: 'Farmhouse Pizza',     category: 'Pizza',    price: 329, rating: 4.4, veg: true,  desc: 'Loaded with capsicum, onion and corn.',   color: '#ef4444' },
  { id: 3,  name: 'Pepperoni Pizza',     category: 'Pizza',    price: 379, rating: 4.6, veg: false, desc: 'Spicy pepperoni with extra cheese.',      color: '#dc2626' },
  { id: 4,  name: 'Aloo Tikki Burger',   category: 'Burgers',  price: 129, rating: 4.2, veg: true,  desc: 'Crispy potato patty with mint mayo.',     color: '#eab308' },
  { id: 5,  name: 'Chicken Zinger',      category: 'Burgers',  price: 189, rating: 4.5, veg: false, desc: 'Crunchy fried chicken fillet burger.',    color: '#d97706' },
  { id: 6,  name: 'Paneer Butter Masala', category: 'Indian',  price: 259, rating: 4.7, veg: true,  desc: 'Creamy tomato gravy with soft paneer.',   color: '#ea580c' },
  { id: 7,  name: 'Chicken Biryani',     category: 'Indian',   price: 299, rating: 4.8, veg: false, desc: 'Fragrant basmati rice cooked with spices.', color: '#b45309' },
  { id: 8,  name: 'Veg Thali',           category: 'Indian',   price: 199, rating: 4.3, veg: true,  desc: 'Roti, dal, sabzi, rice and sweet.',       color: '#65a30d' },
  { id: 9,  name: 'Gulab Jamun',         category: 'Desserts', price: 79,  rating: 4.6, veg: true,  desc: 'Warm milk dumplings in sugar syrup.',     color: '#9a3412' },
  { id: 10, name: 'Chocolate Brownie',   category: 'Desserts', price: 119, rating: 4.7, veg: true,  desc: 'Fudgy brownie with chocolate sauce.',     color: '#78350f' },
  { id: 11, name: 'Mango Lassi',         category: 'Drinks',   price: 89,  rating: 4.5, veg: true,  desc: 'Chilled yoghurt drink with mango.',       color: '#f59e0b' },
  { id: 12, name: 'Cold Coffee',         category: 'Drinks',   price: 109, rating: 4.4, veg: true,  desc: 'Thick and creamy iced coffee.',           color: '#92400e' },
];
