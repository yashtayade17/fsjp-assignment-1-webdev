// Cart state is managed with useReducer
export const initialCart = { items: [], coupon: null };

export function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD': {
      const found = state.items.find((i) => i.id === action.item.id);
      const items = found
        ? state.items.map((i) => (i.id === found.id ? { ...i, qty: i.qty + 1 } : i))
        : [...state.items, { ...action.item, qty: 1 }];
      return { ...state, items };
    }
    case 'INCREASE':
      return { ...state, items: state.items.map((i) => (i.id === action.id ? { ...i, qty: i.qty + 1 } : i)) };
    case 'DECREASE':
      return {
        ...state,
        items: state.items
          .map((i) => (i.id === action.id ? { ...i, qty: i.qty - 1 } : i))
          .filter((i) => i.qty > 0),
      };
    case 'REMOVE':
      return { ...state, items: state.items.filter((i) => i.id !== action.id) };
    case 'APPLY_COUPON':
      return { ...state, coupon: action.code };
    case 'CLEAR':
      return initialCart;
    default:
      return state;
  }
}

// Helper to calculate the bill
export function getBill(cart) {
  const subtotal = cart.items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const discount = cart.coupon === 'FOOD10' ? Math.round(subtotal * 0.1) : 0;
  const gst = Math.round((subtotal - discount) * 0.05);
  const delivery = subtotal === 0 || subtotal >= 500 ? 0 : 40;
  return { subtotal, discount, gst, delivery, total: subtotal - discount + gst + delivery };
}
