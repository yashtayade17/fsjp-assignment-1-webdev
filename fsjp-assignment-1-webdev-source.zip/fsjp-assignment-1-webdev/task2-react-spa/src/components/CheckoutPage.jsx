import { useState } from 'react';
import { getBill } from '../reducers/cartReducer.js';

// Props: cart, onPlaceOrder(details), onNavigate()
export default function CheckoutPage({ cart, onPlaceOrder, onNavigate }) {
  const [form, setForm] = useState({ name: '', phone: '', address: '', payment: 'upi' });
  const [errors, setErrors] = useState({});
  const bill = getBill(cart);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const validate = () => {
    const err = {};
    if (form.name.trim().length < 3) err.name = 'Enter your full name';
    if (!/^[6-9]\d{9}$/.test(form.phone)) err.phone = 'Enter a valid 10-digit mobile number';
    if (form.address.trim().length < 10) err.address = 'Enter your complete delivery address';
    return err;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const err = validate();
    setErrors(err);
    if (Object.keys(err).length === 0) onPlaceOrder(form);
  };

  if (cart.items.length === 0) {
    return (
      <div className="container center-box">
        <h2>Nothing to checkout</h2>
        <button className="btn btn-primary" onClick={() => onNavigate('menu')}>Back to Menu</button>
      </div>
    );
  }

  return (
    <div className="container page">
      <h2>Checkout</h2>
      <div className="cart-layout">
        <form className="form-box" onSubmit={handleSubmit} noValidate>
          <label>Full Name
            <input name="name" value={form.name} onChange={handleChange} placeholder="Your name" />
            {errors.name && <small className="err">{errors.name}</small>}
          </label>
          <label>Mobile Number
            <input name="phone" value={form.phone} onChange={handleChange} placeholder="10-digit number" maxLength="10" />
            {errors.phone && <small className="err">{errors.phone}</small>}
          </label>
          <label>Delivery Address
            <textarea name="address" rows="3" value={form.address} onChange={handleChange} placeholder="House no, street, area, city" />
            {errors.address && <small className="err">{errors.address}</small>}
          </label>
          <label>Payment Method
            <select name="payment" value={form.payment} onChange={handleChange}>
              <option value="upi">UPI</option>
              <option value="card">Credit / Debit Card</option>
              <option value="cod">Cash on Delivery</option>
            </select>
          </label>
          <button className="btn btn-primary full" type="submit">Place Order - &#8377;{bill.total}</button>
          <button type="button" className="btn-link" onClick={() => onNavigate('cart')}>Back to cart</button>
        </form>

        <aside className="summary">
          <h3>Order Items</h3>
          {cart.items.map((i) => (
            <div className="line" key={i.id}><span>{i.name} x {i.qty}</span><span>&#8377;{i.price * i.qty}</span></div>
          ))}
          <div className="line total"><span>Total payable</span><span>&#8377;{bill.total}</span></div>
        </aside>
      </div>
    </div>
  );
}
