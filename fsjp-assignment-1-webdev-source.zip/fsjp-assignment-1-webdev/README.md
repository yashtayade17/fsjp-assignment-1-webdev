# FSJP Assignment 1 - Web Development

| Task | Folder | Tech |
|------|--------|------|
| Task 1 - Personal Portfolio Website | `task1-portfolio/` | HTML5, CSS3, Bootstrap 5 |
| Task 2 - FoodieHub (Online Food Ordering SPA) | `task2-react-spa/` | React.js (Vite) |

See the README inside each folder for details and run instructions.
