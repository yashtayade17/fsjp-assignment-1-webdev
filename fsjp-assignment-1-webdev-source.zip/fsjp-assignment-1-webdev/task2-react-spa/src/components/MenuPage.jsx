import { useState } from 'react';
import { CATEGORIES, MENU } from '../data/menu.js';
import MenuCard from './MenuCard.jsx';

// Props: cartItems, onAdd(item)
export default function MenuPage({ cartItems, onAdd }) {
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [vegOnly, setVegOnly] = useState(false);
  const [sort, setSort] = useState('default');

  // Filter + sort the menu on every render
  let dishes = MENU.filter(
    (d) =>
      (category === 'All' || d.category === category) &&
      (!vegOnly || d.veg) &&
      d.name.toLowerCase().includes(search.toLowerCase())
  );
  if (sort === 'low') dishes = [...dishes].sort((a, b) => a.price - b.price);
  if (sort === 'high') dishes = [...dishes].sort((a, b) => b.price - a.price);
  if (sort === 'rating') dishes = [...dishes].sort((a, b) => b.rating - a.rating);

  return (
    <>
      <section className="hero">
        <h1>Hungry? We deliver happiness.</h1>
        <p>Order your favourite meals online - fresh, fast and affordable.</p>
        <input
          className="search"
          type="text"
          placeholder="Search for a dish..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </section>

      <div className="container">
        <div className="chips">
          {CATEGORIES.map((c) => (
            <button key={c} className={`chip ${c === category ? 'selected' : ''}`} onClick={() => setCategory(c)}>
              {c}
            </button>
          ))}
        </div>

        <div className="toolbar">
          <label className="check">
            <input type="checkbox" checked={vegOnly} onChange={(e) => setVegOnly(e.target.checked)} /> Veg only
          </label>
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="default">Sort: Recommended</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>
        </div>

        {dishes.length === 0 ? (
          <p className="empty">No dishes found. Try a different search.</p>
        ) : (
          <div className="grid">
            {dishes.map((d) => {
              const inCart = cartItems.find((i) => i.id === d.id);
              return <MenuCard key={d.id} item={d} qty={inCart ? inCart.qty : 0} onAdd={() => onAdd(d)} />;
            })}
          </div>
        )}
      </div>
    </>
  );
}
