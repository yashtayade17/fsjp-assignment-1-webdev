// Props: order (details + id + total), onNavigate()
export default function OrderSuccess({ order, onNavigate }) {
  return (
    <div className="container center-box success">
      <div className="tick">&#10003;</div>
      <h2>Order placed successfully!</h2>
      <p>Thank you, <strong>{order.name}</strong>. Your food will reach you in about 30 minutes.</p>
      <div className="order-card">
        <div className="line"><span>Order ID</span><strong>{order.id}</strong></div>
        <div className="line"><span>Payment</span><strong>{order.payment.toUpperCase()}</strong></div>
        <div className="line"><span>Amount</span><strong>&#8377;{order.total}</strong></div>
        <div className="line"><span>Deliver to</span><strong>{order.address}</strong></div>
      </div>
      <button className="btn btn-primary" onClick={() => onNavigate('menu')}>Order something else</button>
    </div>
  );
}
