import DishIcon from './DishIcon.jsx';

// Props: item (dish object), qty (already in cart), onAdd()
export default function MenuCard({ item, qty, onAdd }) {
  return (
    <div className="card">
      <div className="card-img" style={{ background: `linear-gradient(135deg, ${item.color}, #ffb3d1)` }}>
        <DishIcon category={item.category} />
        <span className={`veg-dot ${item.veg ? 'veg' : 'nonveg'}`} title={item.veg ? 'Veg' : 'Non-veg'} />
      </div>
      <div className="card-body">
        <div className="card-top">
          <h3>{item.name}</h3>
          <span className="rating">{item.rating} &#9733;</span>
        </div>
        <p>{item.desc}</p>
        <div className="card-bottom">
          <strong>&#8377;{item.price}</strong>
          <button className="btn btn-primary" onClick={onAdd}>
            {qty > 0 ? `Add more (${qty})` : 'Add to cart'}
          </button>
        </div>
      </div>
    </div>
  );
}
